
{-# LANGUAGE NoImplicitPrelude, InstanceSigs #-}
-- | Implement instances and convenience functions for the 'Monad' typeclass.
module Exercises where

import Base hiding ((>>))
import Functor hiding ((<$>))
import Applicative hiding ((<*>))
import Monad
import Traversable ( Traversable, traverse )
import Data.Foldable ( Foldable, foldl, foldr)


-- | 'return' is just 'pure', which is available because a Monad is also an Applicative
return :: (Monad m) => a -> m a
return = pure

-- | Rewrite /fmap/ '(<$>)' using Monads
-- You must use (=<<)
-- >>> (+1) <$> [1, 2, 3]
-- [2,3,4]
-- >>> (+1) <$> Nothing
-- Nothing
(<$>) :: Monad f => (a -> b) -> f a -> f b
(<$>) f a = return . f =<< a

-- | Flatten a combined structure to a single structure.
-- /Hint/: Use (=<<) and pass a very, very simple function in as the first argument.
--
-- List Monad: join concatenates
-- >>> join [[1, 2, 3], [1, 2]]
-- [1,2,3,1,2]
--
-- Maybe Monad: join flattens nested maybes
-- >>> join (Just Nothing)
-- Nothing
--
-- >>> join (Just (Just 7))
-- Just 7
--
-- function Monad: join passes one argument to a binary function twice.
-- >>> (join (,)) 3
-- (3,3)
--
-- >>> (join (+)) 3
-- 6
--
join :: Monad f => f (f a) -> f a
join = (=<<) id

-- | Implement a flipped version of '=<<', however, use only 'join' and '<$>'.
--
-- Divide an integer by two if it is even.
--
-- >>> :{
-- half x | even x    = Just (x `div` 2)
--        | otherwise = Nothing
-- :}
--
-- >>> Just 20 >>= half
-- Just 10
--
-- >>> Just 20 >>= half >>= half >>= half
-- Nothing
(>>=) :: Monad f => f a -> (a->f b) -> f b
(>>=) a f = join $ f <$> a
-- (>>=) a f = f =<< a
-- | Sequentially call two monadic actions
-- /Hint/: use `(>>=)` to sequence the two actions, but ignore the value from the first.
--
-- >>> [1,2,3] >> [2,3,4]
-- [2,3,4,2,3,4,2,3,4]
(>>) :: Monad m => m a -> m b -> m b
(>>) a b = a >>= const b

-- | Implement composition within the 'Monad' environment. Called: "Kleisli
-- composition."
-- /Hint/: Apply one of the two functions directly, and then use (>>=) or (=<<).
--
-- >>> (\n -> [n, n]) <=< (\n -> [n + 1, n + 2]) $ 1
-- [2,2,3,3]
(<=<) :: Monad f => (b -> f c) -> (a -> f b) -> a -> f c
(<=<) f1 f2 a = f1 =<< f2 a
infixr 1 <=<


-- | Ignores the second value, and puts the first value in a context
--
-- >>> 1 <$ Just 5
-- Just 1
-- >>> 3 <$ [1,2,3,4]
-- [3,3,3,3]
(<$) :: Monad f => a -> f b -> f a 
(<$) a b = const a <$> b

--  x y = (\_ -> x) <$> y

-- | Rewrite /apply/ '(<*>)' using /bind/ @(=<<)@ and /fmap/ '(<$>)'.
-- /Hint/: Look closely at the type of (=<<) above.  In the expression 'f =<< x':
--                x is a thing in the context, 
--                f is a function that is applied to thing (after it is taken out of the context) 
--         The first argument to <*> is a function of type f (a -> b), i.e. a function inside the context.
--         The second argument to <*> is a thing in the context.
--         You can use =<< to get the function out of the context.
--         The first argument to =<< needs to be a function that puts its result in the context.
-- >>> Just (+10) <*> Just 8
-- Just 18
(<*>) :: Monad f => f (a->b) -> f a -> f b
(<*>) f a =  (\x -> x <$> a) =<< f
infixl 4 <*>

-- | map a function with a monadic effect across a Traversable.
-- /Hint/: this is kind of a trick question, look closely at the type of mapM
-- and look at the type of the function that we defined for Traversable in Week 9 -
-- keeping in mind that a Monad is also Applicative.  Note that we are also
-- importing the solution to Traversable.hs from Week9.
--
-- >>> doubleIfNotBig n = if n < 3 then Just (n+n) else Nothing
-- >>> mapM doubleIfNotBig [1,2,3,4]
-- Nothing
-- >>> mapM doubleIfNotBig [1,2,1,2]
-- Just [2,4,2,4]
-- 
mapM :: (Monad m, Traversable t) => (a -> m b) -> t a -> m (t b)
mapM = traverse

-- | map a function with a monadic effect across a Foldable - disregard the results but keep the effect.
-- /Hint/: use `foldr`.  
-- /Hint/: Note that we are returning unit `()` in the Monad.  You'll need to put a `()` into the Monad as the initial value for the foldr.
-- /Hint/: Use `>>` for the sequencing.
--
-- >>> doubleIfNotBig n = if n < 3 then Just (n+n) else Nothing
-- >>> mapM_ doubleIfNotBig [1,2,3,4]
-- Nothing
-- >>> mapM_ doubleIfNotBig [1,2,1,2]
-- Just ()
mapM_ :: (Foldable t, Monad m) => (a -> m b) -> t a -> m ()
mapM_ f = foldr (\elem acc -> f elem >> acc) (return ())

-- | Fold a list using a monadic function.
--
-- /Tip:/ Fold the monad from left to right on the list of arguments.
-- /Hint:/ It's just like the recursive foldleft we implemented in lectures in week 9, but:
--         In the base case, use return to put the accumulator into the context
--         In the general case, you will use bind to apply the specified function
--
-- Example: Sum the elements in a list, but fail if any is greater than 10.
--
-- >>> :{
-- small acc x
--   | x < 10 = Just (acc + x)
--   | otherwise = Nothing
-- :}
--
-- >>> foldM small 0 [1..9]
-- Just 45
--
-- >>> foldM small 0 [1..100]
-- Nothing
foldM :: Monad f => (b -> a -> f b) -> b -> [a] -> f b
foldM _ acc [] = return acc
foldM f acc (x:xs) = f acc x >>= \r -> foldM f r xs