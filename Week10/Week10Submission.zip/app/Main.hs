import Prelude
import Control.Monad
import FileIO

import qualified System.Environment as E

-- | Read the arguments passed to `main`.
getArgs :: IO [String]
getArgs = E.getArgs

-- | Either using a file specified as the command-line arg, or, if none is specified,
-- Prompt user for a file, print the content of each of the files specified in the file.
--
-- /Hint:/ use `getArgs` and `run`
--
-- You can run this function in GHCi by calling:
-- > :main "input.txt"
main :: IO ()
main = undefined