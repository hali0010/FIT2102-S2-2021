/* 
Complete the following table when you submit this file:

Surname     | Firstname | email | Contribution% | Any issues?
=============================================================
Person 1... |           |       | 25%           |
Person 2... |           |       | 25%           |
Person 3... |           |       | 25%           |
Person 4... |           |       | 25%           |

complete Worksheet 4 by entering code in the places marked below...

For full instructions and tests open the file worksheetChecklist.html
in Chrome browser.  Keep it open side-by-side with your editor window.
You will edit this file (main.ts), save it, and reload the 
browser window to run the test. 
*/

/*
    Exercise 1 - General Purpose infinite sequence function
 */

interface LazySequence<T> {
    value: T;
    next(): LazySequence<T>;
}

/*
    Exercise 2
 */

/*
    Exercise 3
 */

/*
    Exercise 4 
 */
