# FIT2102 Week 9 Tutorial Code
[Worksheet](https://docs.google.com/document/d/1cUGRjx9ep3MzmRgB_0H_3bHD704GmmwTwMPqQVZCPdw/edit#bookmark=id.18mq3ihly7vh)