{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
-- | Basic game of rock, paper, scissors.
module RockPaperScissors where

-- $setup
-- >>> import Prelude(fst, snd)
-- >>> import Control.Applicative
-- >>> rps = [Rock, Paper, Scissors]
-- >>> combinations = liftA2 (,) rps rps
-- >>> insight f = map (liftA2 f fst snd)

-- | Types for the game choices: rock, paper or scissors.
data RockPaperScissors = Rock | Paper | Scissors

-- | Result of a game: either one player won, or it's a draw.
data Result = Player1 | Player2 | Draw
  deriving(Eq, Show)

-- | A hand should print as:
--
--  * Rock: \"R\"
--  * Paper: \"P\"
--  * Scissors: \"S\"
--
-- >>> map show rps
-- ["R","P","S"]
instance Show RockPaperScissors where
  show Rock = "R"
  show Paper = "P"
  show Scissors = "S"

-- | Equality between members.
--
-- >>> insight (==) combinations
-- [True,False,False,False,True,False,False,False,True]
instance Eq RockPaperScissors where
  (==) Rock Rock = True 
  (==) Scissors Scissors = True
  (==) Paper Paper = True
  (==) Rock Scissors = False 
  (==) Rock Paper = False
  (==) Scissors Rock = False 
  (==) Scissors Paper = False
  (==) Paper Rock = False        
  (==) Paper Scissors = False
-- | Ordering to determine winning moves.
--
-- >>> insight compare combinations
-- [EQ,LT,GT,GT,EQ,LT,LT,GT,EQ]
instance Ord RockPaperScissors where
  compare Rock Scissors = GT
  compare Rock Paper = LT
  compare Rock Rock = EQ
  compare Scissors Paper = GT
  compare Scissors Rock = LT
  compare Scissors Scissors = EQ
  compare Paper Rock = GT
  compare Paper Scissors = LT
  compare Paper Paper = EQ

-- | Tell which player won.
--
-- >>> insight whoWon combinations
-- [Draw,Player2,Player1,Player1,Draw,Player2,Player2,Player1,Draw]
whoWon :: RockPaperScissors -> RockPaperScissors -> Result
whoWon a b 
  | a == b = Draw
  | a > b = Player1
  | a < b = Player2  


-- | True if the first player has won @n@ or more times.
--
-- >>> competition 2 [Rock, Paper, Paper, Scissors] [Rock, Scissors, Rock, Paper]
-- True
--
-- >>> competition 2 [Paper, Paper, Paper, Scissors] [Rock, Scissors, Rock, Paper]
-- True
--
-- >>> competition 2 [Rock, Paper, Paper, Scissors] [Rock, Scissors, Rock, Scissors]
-- False
--
-- >>> competition 2 [Rock, Paper, Paper, Scissors] [Rock, Scissors, Rock, Rock]
-- False
competition :: Int -> [RockPaperScissors] -> [RockPaperScissors] -> Bool
competition n ar1 ar2 = length (filter (==Player1) (zipWith whoWon ar1 ar2)) >=n
-- competition n ar1 ar2 = filter (x -> x[0] > x[1]) (map ((x,y) -> [x,y]) ar1 ar2)
-- competition 0 _ _ = True
-- competition n ar1 ar2 = competitionAux n (length ar1) ar1 ar2

-- competitionAux :: Int -> Int -> [RockPaperScissors] -> [RockPaperScissors] -> Bool
-- competitionAux 0 _ _ _ = True 
-- competitionAux n 0 _ _ = n == 0
-- competitionAux n i ar1 ar2
--   | ar1[0] <= ar2[0] = competitionAux n (i-1) ar1 ar2
--   | ar1[0] > ar2[0] = competitionAux (n-1) (i-1) ar1 ar2

-- | Generalised competition
--
-- >>> competition' [Rock, Rock, Rock] [Paper, Paper, Paper]
-- Player2
-- >>> competition' [Scissors, Scissors, Scissors] [Paper, Paper, Paper]
-- Player1
-- >>> competition' [Scissors, Scissors, Rock] [Paper, Scissors, Paper]
-- Draw
competition' :: [RockPaperScissors] -> [RockPaperScissors] -> Result
competition' ar1 ar2
  | competition (length ar1) ar1 ar2 = Player1
  | competition (length ar1) ar2 ar1 = Player2
  | otherwise = Draw